# -*- coding: utf-8 -*-
"""
Created on Wed Nov 22 05:01:33 2023

@author: Admin
"""
# question (1a)
print ('\n\n', "---------------------Questin 1a-------------------------- ",'\n') 

name ="sadiq"
print("Hello ",  name , "I am taking some phyton classes ")
print("Hello ",  name.upper() , "I am taking some phyton classes ")
print("Hello ",  name.title() , "I am taking some phyton classes ")


print ('\n\n', "---------------------Questin 1b-------------------------- ",'\n') 

famous_person = "Aristotle" 
message= '"he who has never learned to obey cannot be a good commander"'
print(famous_person, "once said, ", message.title())

# question (1c)
print ('\n\n', "---------------------Questin 1c-------------------------- ",'\n') 
classMates =  ['Nuhu ','Zannah','Umar ', 'Najeeb','Shehu']
for i in classMates:
    print("Hi!", i, "\t\t"'" Submit your assingment before 03 December, 2023"')
    
